package inheritance;

public class SavingsAcc extends BankAcc{
	
	int Balance;
	int min_bal = 1000;
	
	SavingsAcc(String Name, int AccNo, int Bal){
		super(Name, AccNo); //call the parent class constructor
		Balance = Bal;
	}
	
	
	String isBalanceMaintained() {
		if(Balance > min_bal) {
			return "Yes";
		}
		else
			return "No";
	}
	
	void DispCust() {
		super.DispCust();
		System.out.println("Balance " + Balance);
		System.out.println("isBalanceMaintained? " + isBalanceMaintained());
	}
	
	public static void main(String[] args) {
		SavingsAcc sa = new SavingsAcc("SKP", 123456, 900);
		sa.DispCust();
	}
	
	

}
