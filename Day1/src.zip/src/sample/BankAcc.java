package sample;

import javax.sound.midi.Synthesizer;

public class BankAcc {
	
	String CustName;
	int cust_AccNo;
	
	BankAcc(String CustName, int cust_AccNo){ //parameterized constuctor
		this.CustName = CustName;
		this.cust_AccNo = cust_AccNo;
	}
	
	void DispCust() {
		System.out.println("Customer Name " + CustName);
		System.out.println("Customer Acc No. " + cust_AccNo);
	}
	
	public static void main(String[] args) {
		BankAcc ba = new BankAcc("SKP", 1234);
		ba.DispCust();
	}

}
