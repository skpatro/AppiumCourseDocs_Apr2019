package sample;

public class Terms {
	
	

	public static void main(String[] args) {
		//Sample("folks");
		
		System.out.println(123);
		System.out.println(12.30);
		
		
	}
	
	public static void Sample(String str) {
		System.out.println("Welcome!" + str);
	}

}
