package collections;

import java.util.HashMap;
import java.util.Map;

public class HashMapTest {

	public static void main(String[] args) {
		Map<String, String> hm = new HashMap();
		
		hm.put("PersonName", "SKP");
		hm.put("PersonGroupName", "Group1");
		hm.put("PersonPhone", "123453642");
		hm.put("PersonPinCode", "768987");
		
		for(Map.Entry map : hm.entrySet()) {
			System.out.println("Key - " + map.getKey() + " | Values - "+ map.getValue());
		}
		
		System.out.println(hm.get("PersonName"));
		//hm.
	}

}
