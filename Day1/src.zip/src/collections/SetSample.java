package collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class SetSample {

	public static void main(String[] args) {
		//Set<String> li = new HashSet<>();
		
		Set<String> li = new TreeSet<>();
		
		li.add("SKP");
		li.add("345");
		li.add("12.30");
		li.add("Tuv");
		
		System.out.println(li);
		
		//System.out.println(li.get(2));
		
		for(String s : li) {
			System.out.println(s);
		}
		
	}

}
