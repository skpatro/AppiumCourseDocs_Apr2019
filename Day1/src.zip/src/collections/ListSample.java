package collections;

import java.util.ArrayList;
import java.util.List;

public class ListSample {

	public static void main(String[] args) {
		List li = new ArrayList<>();
		
		li.add("SKP");
		li.add(345);
		li.add(12.30);
		li.add(345);
		
		System.out.println(li);
		
		System.out.println(li.get(2));
		
		for(int i = 0; i< li.size() ; i++) {
			System.out.println(li.get(i));
		}
		
	}

}
