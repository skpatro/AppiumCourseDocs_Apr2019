package arrays;

public class SampleArray {

	public static void main(String[] args) {
		//int Arr[] = new int[5];
		int Arr[] = {1,4,5,6};
		
		/*Arr[0] = 1;
		Arr[1] = 6;
		Arr[2] = 9;*/
		
		for(int j = 0; j < Arr.length ; j ++) {
			System.out.println(Arr[j]);
		}
		
		//System.out.println(Arr[7]);
	}

}
