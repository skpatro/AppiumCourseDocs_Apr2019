package com.sampleProj.TestNGDetails.testNGAnnotation;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestNGAnnot {
	
	@BeforeSuite
	public void setup() {
		System.out.println("BeforeSuite: initiate db connection");
	}
	
	@BeforeTest
	public void openURL() {
		System.out.println("BeforeTest: open AUT URL");
	}
	
	@Test(description = "Desc - TestCase 1 with logic")
	public void tc01() {
		System.out.println("Testcase01: TC logic");
	}
	
	@Test(description = "Desc - TestCase 2 with logic")
	public void tc02() {
		System.out.println("Testcase02: TC logic");
	}
	
	@AfterSuite
	public void tearDown() {
		System.out.println("AfterSuite: close db connection");
	}
	
	@AfterTest
	public void closeURL() {
		System.out.println("AfterTest: close AUT URL");
	}

}
