package com.sampleProj.TestNGDetails.testNGAnnotation;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestNGPriority {
	
	@Test(priority = 1)
	public void login() {
		System.out.println("Testcase01: TC logic");
	}
	
	@Test(priority = 2)
	public void clickOnNext() {
		System.out.println("Testcase02: TC logic");
	}
	
	@Test(priority = 3)
	public void navigateSettings() {
		System.out.println("tc03: TC logic");
	}
	
	@Test(priority = 4)
	public void signOut() {
		System.out.println("tc04: TC logic");
	}

}
