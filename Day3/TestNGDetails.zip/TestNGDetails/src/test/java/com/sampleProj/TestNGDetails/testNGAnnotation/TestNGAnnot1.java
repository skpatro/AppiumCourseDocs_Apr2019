package com.sampleProj.TestNGDetails.testNGAnnotation;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestNGAnnot1 {
	
	@BeforeMethod
	public void openURL() {
		System.out.println("BeforeMethod: open URL");
	}
	
	@Test(enabled = true)
	public void tc03() {
		System.out.println("Testcase03: TC logic");
	}
	
	//@Test
	public void tc04() {
		System.out.println("Testcase04: TC logic");
	}
	
	@AfterMethod
	public void closeURL() {
		System.out.println("AfterMethod: close AUT URL");
	}

}
