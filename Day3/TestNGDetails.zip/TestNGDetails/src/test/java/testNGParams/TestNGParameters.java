package testNGParams;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNGParameters {
	
	@Test
	@Parameters({"URL","TextValue"})
	public void paramTest(String URL, String value) {
		System.out.println("URL to load " + URL);
		System.out.println("Text to search " + value);
	}
}
