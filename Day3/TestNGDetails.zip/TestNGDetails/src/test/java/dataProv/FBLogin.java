package dataProv;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class FBLogin {
	
	@Test(dataProvider = "dp")
	public void LoginTest(String uName, String password) {
		System.out.println("UserName " + uName);
		System.out.println("Password " + password);
	}
	
	@DataProvider(name = "dp")
	public Object[][] getTestData(){
		Object[][] obj = {{"abc", "abc123"}, {"def", "def456"}, {"ghi", "ghi789"}};
		return obj;
	}

}
