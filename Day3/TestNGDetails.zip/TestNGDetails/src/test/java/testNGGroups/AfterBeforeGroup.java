package testNGGroups;

import org.testng.annotations.AfterGroups;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AfterBeforeGroup {
	
	@BeforeGroups("DB")
	public void OpenDB() {
		System.out.println("BeforeGroups: initiate db connection");
	}
	
	@AfterGroups("DB")
	public void  closeDB() {
		System.out.println("AfterGroups: close DB");
	}
	
	@BeforeGroups("UI")
	public void login() {
		System.out.println("BeforeGroups: login");
	}
	
	@AfterGroups("UI")
	public void  logout() {
		System.out.println("AfterGGroups: Logout");
	}
	
	@Test(groups="DB")
	public void tc01() {
		System.out.println("Testcase01: DB TC");
	}
	
	@Test(groups="DB")
	public void tc02() {
		System.out.println("Testcase02: DB TC");
	}
	
	@Test(groups="UI")
	public void tc03() {
		System.out.println("TestCase03: UI TC");
	}

}
