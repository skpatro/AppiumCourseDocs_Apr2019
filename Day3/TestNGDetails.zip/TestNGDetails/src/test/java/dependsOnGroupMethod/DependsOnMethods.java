package dependsOnGroupMethod;

import org.testng.annotations.Test;

public class DependsOnMethods {
	
	@Test
	public void fbLogin() {
		System.out.println("Login to FB");
		int i = 7;
		int result = i/0;
	}
	
	@Test(dependsOnMethods = {"fbLogin"})
	public void openProfile() {
		System.out.println("openProfile(): logic");
	}
	
	@Test(dependsOnMethods = {"fbLogin"})
	public void postMessage() {
		System.out.println("postMessage(): logic");
	}
}
