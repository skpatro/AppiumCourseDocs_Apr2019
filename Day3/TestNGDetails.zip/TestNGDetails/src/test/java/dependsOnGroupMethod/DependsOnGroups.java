package dependsOnGroupMethod;

import org.testng.annotations.Test;

public class DependsOnGroups {

	@Test(groups = "ab")
	public void fbLogin() {
		System.out.println("Login to FB");
		int i = 7;
		int result = i/0;
	}
	
	@Test(groups = "a")
	public void fbDB() {
		System.out.println("Login to FB DB");
	}
	
	@Test(dependsOnGroups = {"a.*"})
	public void openProfile() {
		System.out.println("openProfile(): logic");
	}
	
	@Test(dependsOnGroups = {"a"})
	public void postMessage() {
		System.out.println("postMessage(): logic");
	}
}
