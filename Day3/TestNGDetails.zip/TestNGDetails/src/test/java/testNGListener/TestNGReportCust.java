package testNGListener;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class TestNGReportCust implements ITestListener {

	public void onTestStart(ITestResult result) {
		System.out.println(result.getMethod() + " started");
		System.out.println(result.getMethod().getDescription());
	}

	public void onTestSuccess(ITestResult result) {
		System.out.println(result.getMethod().getMethodName() + " Passed");
	}

	public void onTestFailure(ITestResult result) {
		System.out.println("Failed because of " + result.getThrowable());
		
	}

	public void onTestSkipped(ITestResult result) {
		System.out.println("Test skipped because of " + result.getThrowable() );
		
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	public void onStart(ITestContext context) {
		System.out.println("======onStart " + context.getName() + "===========");
		
	}

	public void onFinish(ITestContext context) {
		System.out.println("======onFinish " + context.getName() + "===========");
		
	}
	

}
