package po;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseclasses.MobileDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class CallHistory {
	
	public CallHistory() {
		PageFactory.initElements(new AppiumFieldDecorator(MobileDriver.getDriver()), this);
	}
	
	@FindBy(xpath = "//android.widget.TextView[@text='ALL']")
	public WebElement allTab;

	@FindBy(id = "com.google.android.dialer:id/primary_action_view")
	public WebElement callItem;
	
	@FindBy(id = "com.google.android.dialer:id/call_log_fragment_root")
	public WebElement callHistoryPane;
	
	

}
