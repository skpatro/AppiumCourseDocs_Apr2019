package po;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseclasses.MobileDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class HomePage {
	
	public HomePage() {
		PageFactory.initElements(new AppiumFieldDecorator(MobileDriver.getDriver()), this);
	}
	
	@FindBy(id = "com.google.android.dialer:id/main_options_menu_button")
	public WebElement ThreeDots;
	
	@FindBy(xpath = "//android.widget.TextView[@text='Call history']")
	public WebElement call_History;
	
	@FindBy(id = "com.google.android.dialer:id/contacts_tab")
	public WebElement contactsTab;
	
	@FindBy(id = "com.google.android.dialer:id/fast_scroller")
	public WebElement contactsPane;
	
	@FindBy(id = "com.google.android.dialer:id/contact_name")
	public List<WebElement> contactNames;
}
