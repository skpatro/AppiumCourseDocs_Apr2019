package tests;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.Test;

import baseclasses.DriverFactory;
import baseclasses.MobileDriver;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AutomationName;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import po.CallHistory;
import po.HomePage;

public class Scrolling {
	
	@Test
	public void Test_Scrolling() throws MalformedURLException, InterruptedException {
		DriverFactory.launchAndroidApp();
		
		HomePage homePage = new HomePage();
		CallHistory callHistory = new CallHistory();
		
		homePage.contactsTab.click();
		
		Dimension dimension = homePage.contactsPane.getSize();
		
		Double ScreenHeightStart = dimension.getHeight() * 0.5;
		int scrollStart = ScreenHeightStart.intValue();
		
		Double ScreenHeightEnd = dimension.getHeight() * 0.2;
		int scrollEnd = ScreenHeightEnd.intValue();
		
		new TouchAction((PerformsTouchActions) MobileDriver.getDriver())
		.press(PointOption.point(0, scrollStart))
		.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
		.moveTo(PointOption.point(0, scrollEnd))
		.release().perform();
		
		Thread.sleep(2000);		
		
		MobileDriver.getDriver().quit();
	}
}


