

import java.io.File;

import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class AppiumServer {
	static AppiumDriverLocalService service;
	
	public static void main(String[] args) throws InterruptedException {
		start();
		Thread.sleep(2000);
		stop();
		System.out.println("server stopped");
	}
	
	public static void start() {
		AppiumServiceBuilder builder = new AppiumServiceBuilder(); 
		builder
        .withAppiumJS(new File("/usr/local/lib/node_modules/appium/build/lib/main.js"))
        .usingDriverExecutable(new File("/usr/local/bin/node"))
        .withIPAddress("127.0.0.1").usingPort(4723)
        .withLogFile(new File("AppiumLogFile.txt"));
        
		if(service == null) {
			service = builder.build();
			service.start();
		}
         
		 System.out.println("Appium server started at - " + service.getUrl().toString());
	}
	
	public static void stop() {
		service.stop();
	}

}
