import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class MobileBrowser {
	
	public static AppiumDriver<MobileElement> driver;
	public static DesiredCapabilities cap;
	
	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		cap = new DesiredCapabilities();
		cap.setCapability("platformName", "Android");
		cap.setCapability("deviceName", "emulator-5554");
		cap.setCapability("automationName", "UiAutomator2");
		cap.setCapability(MobileCapabilityType.PLATFORM_VERSION, "9");
		cap.setCapability("browserName", "Chrome");
		System.setProperty("webdriver.chrome.driver", "/Users/sunilkumarpatro/Desktop/chromedriver");
		driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), cap);
		Thread.sleep(1000);
		
		driver.get("https://www.google.com");;
		System.out.println(driver.getTitle());
			
		driver.quit();
		
	}
	

}
