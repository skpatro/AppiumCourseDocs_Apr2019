import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

public class IOSTest {
	
	public static AppiumDriver<MobileElement> driver;
	public static DesiredCapabilities cap;
	
	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		cap = new DesiredCapabilities();
		cap.setCapability("platformName", "iOS");
		cap.setCapability("deviceName", "iPhone X");
		cap.setCapability("automationName", "XCUITest");
		cap.setCapability("platformVersion", "12.2");
		cap.setCapability("bundleId", "com.SamadiPour.SimpleCalculator");
		
		driver = new IOSDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), cap);
		Thread.sleep(1000);
		driver.findElement(By.name("1")).click();
		driver.findElement(By.name("+")).click();
		driver.findElement(By.name("8")).click();
		driver.findElement(By.name("=")).click();
		String result = driver.findElement(By.xpath("//XCUIElementTypeTextView")).getAttribute("value");
		System.out.println(result);
		
		driver.quit();
		
	}
	

}
