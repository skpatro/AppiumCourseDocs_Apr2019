package android.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseclasses.MobileDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class HomePage {
	
	public HomePage() {
		PageFactory.initElements(new AppiumFieldDecorator(MobileDriver.getDriver()), this);
	}
	
	@FindBy(id = "com.android.calculator2:id/digit_1")
	public WebElement digitOne;
	
	@FindBy(id = "com.android.calculator2:id/digit_6")
	public WebElement digitSix;
	
	@FindBy(id = "com.android.calculator2:id/op_add")
	public WebElement Add;
	
	@FindBy(id = "com.android.calculator2:id/result")
	public WebElement Result;
	
	@FindBy(id = "com.android.calculator2:id/eq")
	public WebElement EqualTo;
	
	public void Add() {
		digitOne.click();
		Add.click();
		digitSix.click();
		EqualTo.click();
	}
	
	public String getResult() {
		return Result.getText();
	}
}
