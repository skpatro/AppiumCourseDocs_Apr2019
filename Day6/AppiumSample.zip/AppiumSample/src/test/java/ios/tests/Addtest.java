package ios.tests;

import java.net.MalformedURLException;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import ios.pageobjects.HomePage;
import baseclasses.DriverFactory;

public class Addtest {
	
	@BeforeMethod
	public void setUp() throws MalformedURLException, InterruptedException {
		DriverFactory.launchIOSApp();
		Thread.sleep(2000);
	}
	
	@Test
	public void AddTest() throws MalformedURLException, InterruptedException {
		HomePage homePage = new HomePage();
		homePage.Add();
		System.out.println(homePage.getResult());
		Assert.assertEquals(homePage.getResult(), "10");
	}
	
	@AfterMethod
	public void tearDown() {
		DriverFactory.closeApp();
	}


}
