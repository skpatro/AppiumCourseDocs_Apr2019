package ios.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseclasses.MobileDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class HomePage {
	
	public HomePage() {
		PageFactory.initElements(new AppiumFieldDecorator(MobileDriver.getDriver()), this);
	}
	
	@FindBy(id = "2")
	public WebElement digitOne;
	
	@FindBy(id = "8")
	public WebElement digitTwo;
	
	@FindBy(id = "+")
	public WebElement Add;
	
	@FindBy(xpath = "//XCUIElementTypeTextView")
	public WebElement Result;
	
	@FindBy(id = "=")
	public WebElement EqualTo;
	
	public void Add() {
		digitOne.click();
		Add.click();
		digitTwo.click();
		EqualTo.click();
	}
	
	public String getResult() {
		return Result.getAttribute("value");
	}

}
