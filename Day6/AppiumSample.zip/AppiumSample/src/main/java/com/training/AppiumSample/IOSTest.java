package com.training.AppiumSample;

import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;


public class IOSTest {
	
	public static AppiumDriver<MobileElement> driver;
	public static DesiredCapabilities cap;
	
	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		cap = new DesiredCapabilities();
		cap.setCapability("platformName", "iOS");
		cap.setCapability("deviceName", "iPhone X");
		cap.setCapability("automationName", "XCUITest");
		cap.setCapability("platformVersion", "12.2");
		cap.setCapability("bundleId", "com.SamadiPour.SimpleCalculator");
		driver = new IOSDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), cap);
		Thread.sleep(1000);
		
		driver.findElement(By.id("2")).click();
		driver.findElement(By.id("+")).click();
		driver.findElement(By.id("8")).click();
		driver.findElement(By.id("=")).click();
		Thread.sleep(1000);
		
		System.out.println(driver.findElement(By.xpath("//XCUIElementTypeTextView")).getAttribute("value"));
		Assert.assertEquals(driver.findElement(By.xpath("//XCUIElementTypeTextView")).getAttribute("value"), "10");
		driver.quit();
		
	}

}
