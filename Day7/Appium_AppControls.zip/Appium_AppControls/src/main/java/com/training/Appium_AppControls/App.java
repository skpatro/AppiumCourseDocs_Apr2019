package com.training.Appium_AppControls;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AutomationName;
import io.appium.java_client.remote.MobileCapabilityType;

/**
 * Hello world!
 *
 */
public class App 
{
	public static AppiumDriver<MobileElement> driver;
	public static DesiredCapabilities cap;
    public static void main( String[] args ) throws MalformedURLException, InterruptedException
    {
    	cap = new DesiredCapabilities();
		cap.setCapability("platformName", "Android");
		cap.setCapability("deviceName", "eb84b64d");
		cap.setCapability("MobileCapabilityType.AUTOMATION_NAME", AutomationName.ANDROID_UIAUTOMATOR2);
		//cap.setCapability("appPackage", "com.android.calculator2");
		//cap.setCapability("appActivity", ".Calculator");
		cap.setCapability("browserName", "Chrome");
		//cap.setCapability(MobileCapabilityType.BROWSER_NAME, BrowserType.CHROME);
		driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), cap);
		Thread.sleep(1000);
		
		System.setProperty("webdriver.chrome.driver", "/Users/sunilkumarpatro/Desktop/chromedriver");
		driver.get("https://m.facebook.com");
		System.out.println(driver.getTitle());
		Thread.sleep(2000);
		driver.findElement(By.id("forgot-password-link")).click();
		System.out.println(driver.getTitle());
		Thread.sleep(2000);
		driver.quit();

    }
}
