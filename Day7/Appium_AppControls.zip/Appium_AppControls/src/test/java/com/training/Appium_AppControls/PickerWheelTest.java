package com.training.Appium_AppControls;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.events.api.general.JavaScriptEventListener;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.AutomationName;

public class PickerWheelTest {

	public static AppiumDriver<MobileElement> driver;
	public static DesiredCapabilities cap;
    public static void main( String[] args ) throws MalformedURLException, InterruptedException
    {
    	cap = new DesiredCapabilities();
		cap.setCapability("platformName", "iOS");
		cap.setCapability("deviceName", "iPhone X");
		cap.setCapability("automationName", "XCUITest");
		cap.setCapability("platformVersion", "12.2");
		cap.setCapability("bundleId", "com.example.apple-samplecode.UICatalog");
		driver = new IOSDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), cap);
		Thread.sleep(1000);
		
		driver.findElement(By.id("Date Picker")).click();
		
		List<MobileElement> pickers = 
				driver.findElements(By.xpath("//XCUIElementTypePickerWheel"));
		
		//alternate way to select picker wheel item
		/*		JavascriptExecutor js =  (JavascriptExecutor) driver;
				Map<String, Object> hp = new HashMap<String, Object>();
				hp.put("order", "next");
				hp.put("offset", 0.15);
				hp.put("element", pickers.get(0));
				js.executeScript("mobile : selectPickerWheelValue", hp);*/
				
		pickers.get(1).sendKeys("11");
		Thread.sleep(1000);
		pickers.get(2).sendKeys("30");
		Thread.sleep(1000);
		pickers.get(3).sendKeys("PM");
		Thread.sleep(1000);
		
		
		System.out.println(pickers.get(0).getAttribute("value"));
		System.out.println(pickers.get(1).getAttribute("value"));
		System.out.println(pickers.get(2).getAttribute("value"));
		System.out.println(pickers.get(3).getAttribute("value"));
		
		Thread.sleep(3000);
		driver.quit();
    }
}
