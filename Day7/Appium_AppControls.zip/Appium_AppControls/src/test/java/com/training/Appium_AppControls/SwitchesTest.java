package com.training.Appium_AppControls;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AutomationName;

public class SwitchesTest {

	public static AppiumDriver<MobileElement> driver;
	public static DesiredCapabilities cap;
    public static void main( String[] args ) throws MalformedURLException, InterruptedException
    {
    	cap = new DesiredCapabilities();
		cap.setCapability("platformName", "Android");
		cap.setCapability("deviceName", "emulator-5554");
		cap.setCapability("MobileCapabilityType.AUTOMATION_NAME", AutomationName.ANDROID_UIAUTOMATOR2);
		cap.setCapability("appPackage", "io.appium.android.apis");
		cap.setCapability("appActivity", ".view.Switches");
		//cap.setCapability(MobileCapabilityType.BROWSER_NAME, BrowserType.CHROME);
		driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), cap);
		Thread.sleep(2000);
		
		//((AndroidDriver) driver).startActivity(new Activity("io.appium.android.apis", "io.appium.android.apis.app.AlertDialogSamples"));
		
		WebElement el = driver.findElement(By.id("Standard switch"));
		
		System.out.println("Switch is - " + el.getAttribute("checked"));
		
		if(el.getAttribute("checked").equals("false")) { 
			el.click(); //Switch it ON
		}
		
		System.out.println(driver.findElement(By.id("Standard switch")).getAttribute("checked"));
	
		
		Thread.sleep(3000);
		driver.quit();
    }
}
