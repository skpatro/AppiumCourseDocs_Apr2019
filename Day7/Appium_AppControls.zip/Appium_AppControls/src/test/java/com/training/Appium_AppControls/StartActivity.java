package com.training.Appium_AppControls;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AutomationName;

public class StartActivity {

	public static AppiumDriver<MobileElement> driver;
	public static DesiredCapabilities cap;
    public static void main( String[] args ) throws MalformedURLException, InterruptedException
    {
    	cap = new DesiredCapabilities();
		cap.setCapability("platformName", "Android");
		cap.setCapability("deviceName", "eb84b64d");
		cap.setCapability("MobileCapabilityType.AUTOMATION_NAME", AutomationName.ANDROID_UIAUTOMATOR2);
		cap.setCapability("appPackage", "io.appium.android.apis");
		cap.setCapability("appActivity", ".ApiDemos");
		//cap.setCapability(MobileCapabilityType.BROWSER_NAME, BrowserType.CHROME);
		driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), cap);
		Thread.sleep(2000);
		
		((AndroidDriver) driver).startActivity(new Activity("io.appium.android.apis", "io.appium.android.apis.app.AlertDialogSamples"));
		
		Thread.sleep(3000);
		driver.quit();
    }
}
