package tests;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.Test;

import baseclasses.DriverFactory;
import baseclasses.MobileDriver;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AutomationName;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import po.CallHistory;
import po.HomePage;

public class Swipe {
	
	@Test
	public void SwipeTest() throws MalformedURLException, InterruptedException {
		DriverFactory.launchAndroidApp();
		
		HomePage homePage = new HomePage();
		CallHistory callHistory = new CallHistory();
		
		homePage.ThreeDots.click();
		homePage.call_History.click();
		callHistory.allTab.click();
		Thread.sleep(1000);

		Dimension dimension = callHistory.callHistoryPane.getSize();
		
		int Anchor = dimension.getHeight()/2; 
		
		Double ScreenWidthStart = dimension.getWidth() * 0.8;
		int scrollStart = ScreenWidthStart.intValue();
		
		Double ScreenWidthEnd = dimension.getWidth() * 0.2;
		int scrollEnd = ScreenWidthEnd.intValue();
		
		new TouchAction((PerformsTouchActions) MobileDriver.getDriver())
		.press(PointOption.point(scrollStart, Anchor))
		.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
		.moveTo(PointOption.point(scrollEnd, Anchor))
		.release().perform();
		
		Thread.sleep(2000);
		MobileDriver.getDriver().navigate().back();
		Thread.sleep(1000);
		MobileDriver.getDriver().quit();

	}
}


