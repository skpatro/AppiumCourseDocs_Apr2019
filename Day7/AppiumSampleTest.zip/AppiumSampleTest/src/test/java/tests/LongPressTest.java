package tests;

import java.net.MalformedURLException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import baseclasses.DriverFactory;
import baseclasses.MobileDriver;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import po.CallHistory;
import po.HomePage;

public class LongPressTest {
	
	@Test
	public void Test_LongPress() throws InterruptedException, MalformedURLException {
		DriverFactory.launchAndroidApp();
		
		HomePage homePage = new HomePage();
		CallHistory callHistory = new CallHistory();
		
		homePage.ThreeDots.click();
		homePage.call_History.click();
		callHistory.allTab.click();
		Thread.sleep(1000);
		
		new TouchAction((PerformsTouchActions) MobileDriver.getDriver())
		.longPress(LongPressOptions.longPressOptions().withElement((ElementOption.element(callHistory.callItem))))
        .release().perform();
		
		Thread.sleep(2000);
		MobileDriver.getDriver().findElement(By.xpath("//android.widget.TextView[@text='Copy number']")).click();
		Thread.sleep(2000);
		
		MobileDriver.getDriver().quit();

	}
	
	public static void LongPress(WebElement el) {
		new TouchAction((PerformsTouchActions) MobileDriver.getDriver())
		.longPress(LongPressOptions.longPressOptions().withElement((ElementOption.element(el))))
        .release().perform();
	}

}
