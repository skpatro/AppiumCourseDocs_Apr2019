package baseclasses;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.AutomationName;
import io.appium.java_client.remote.MobileCapabilityType;

public class DriverFactory {
	static AppiumDriver<MobileElement> driver = null;
    static DesiredCapabilities cap;  
    
    public static void launchAndroidApp() throws MalformedURLException {
    	cap = new DesiredCapabilities();
        cap.setCapability("platformName", "Android");
        cap.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.ANDROID_UIAUTOMATOR2);
        //cap.setCapability("deviceName", "emulator-5554");
        cap.setCapability("deviceName", "emulator-5554");
		cap.setCapability("appPackage", "com.google.android.dialer");
		cap.setCapability("appActivity", ".DialtactsActivity");
        driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), cap);
        //System.out.println("Is App installed? " + driver.isAppInstalled("com.thomsonreuters.cs.samba"));
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        MobileDriver.setWebDriver(driver);
        Assert.assertNotNull(driver);
    }
    
    public static void launchIOSApp() throws MalformedURLException {
    	cap = new DesiredCapabilities();
        cap.setCapability("platformName", "iOS");
        //cap.setCapability("deviceName", "iPhone 8 Plus");
        cap.setCapability("deviceName", "iPhone X");
        cap.setCapability("platformVersion", "12.2");
        cap.setCapability("automationName", "XCUITest");
        cap.setCapability("bundleId", "com.SamadiPour.SimpleCalculator");          
        driver = new IOSDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), cap);
        //System.out.println("Is App installed? " + driver.isAppInstalled("com.thomsonreuters.samba"));
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        MobileDriver.setWebDriver(driver);
        Assert.assertNotNull(driver);
    }
    
    public static void closeApp() {
    	driver.quit();
    }
}
