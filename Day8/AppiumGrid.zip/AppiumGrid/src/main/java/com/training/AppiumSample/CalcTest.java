package com.training.AppiumSample;

import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.AutomationName;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class CalcTest 
{
	public static DesiredCapabilities cap;
	private static ThreadLocal<AndroidDriver> tlDriver = new ThreadLocal<>();
	AppiumDriverLocalService service;
	 
	@BeforeTest(alwaysRun = true)
	@Parameters({"udid", "sysPort", "platformVersion", "port"})
	public void setup(String udid, int SysPort, String platformVersion, int port)  throws MalformedURLException, InterruptedException {
		
		service = new AppiumServiceBuilder().usingPort(port).build();
		
		if(service == null || !service.isRunning()) {
			service.start();
		}
		
		cap = new DesiredCapabilities();
        cap.setCapability("platformName", "Android");
        cap.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.ANDROID_UIAUTOMATOR2);
        cap.setCapability("deviceName", udid);
        cap.setCapability("udid", udid);
        cap.setCapability("systemPort", SysPort);
        cap.setCapability("platformVersion", platformVersion);
        cap.setCapability("BUILD_ID", "dontKillMe");
    	cap.setCapability("appPackage", "com.android.calculator2");
		cap.setCapability("appActivity", ".Calculator");
		
		setTLDriver(new AndroidDriver<>(service.getUrl(), cap));
		
		Thread.sleep(1000);
		System.out.println("Process" + Thread.currentThread().getId());
	}
	
	@Test
	public void test1() throws InterruptedException {
	
		getTLDriver().findElement(By.id("com.android.calculator2:id/digit_1")).click();
		getTLDriver().findElement(By.id("com.android.calculator2:id/op_add")).click();
		getTLDriver().findElement(By.id("com.android.calculator2:id/digit_6")).click();
		getTLDriver().findElement(By.id("com.android.calculator2:id/eq")).click();
		Thread.sleep(1000);
		System.out.println("Result - " +getTLDriver().findElement(By.id("com.android.calculator2:id/result")).getText());
		Assert.assertEquals(getTLDriver().findElement(By.id("com.android.calculator2:id/result")).getText(), "7");
		
	}
	
	 public synchronized static void setTLDriver(AndroidDriver driver) 
	 {
		 tlDriver.set(driver);
	 }
	 
	 public synchronized static AndroidDriver getTLDriver() 
	 {
		 return tlDriver.get();
	 }
	    
	 @AfterTest(alwaysRun = true)
	 public void tearDown() 
	 {
	 	getTLDriver().quit();
	   	service.stop();
	 }
}
