package android.tests;

import java.net.MalformedURLException;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import android.pageobjects.HomePage;
import baseclasses.DriverFactory;

public class Addtest {
	@BeforeTest(alwaysRun = true)
		@Parameters({"udid", "systemPort", "platformVersion", "port"})
		public void setUp(String udid, int SystemPort, String platformVersion, int port) throws MalformedURLException, InterruptedException {
			DriverFactory.launchAndroidApp(udid, SystemPort, platformVersion, port);
			Thread.sleep(2000);
		}
		
		@Test
		public void AddTest() throws MalformedURLException, InterruptedException {
			//DriverFactory.launchAndroidApp();
			Thread.sleep(2000);
			HomePage homePage = new HomePage();
			homePage.Add();
			System.out.println(homePage.getResult());
			Assert.assertEquals(homePage.getResult(), "7");
			DriverFactory.closeApp();
		}
		
		//@AfterMethod
		public void tearDown() {
			DriverFactory.closeApp();
		}

}
