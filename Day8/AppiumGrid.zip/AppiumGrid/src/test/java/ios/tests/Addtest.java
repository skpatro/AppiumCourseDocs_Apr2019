package ios.tests;

import java.net.MalformedURLException;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import ios.pageobjects.HomePage;
import baseclasses.DriverFactory;

public class Addtest {
	
	/*
	@BeforeMethod
	@Parameters({"udid", "wdaLocalPort", "platformVersion"})
	public void setUp(String udid, int wdaLocalPort, String platformVersion) throws MalformedURLException, InterruptedException {
		DriverFactory.launchIOSApp(udid, wdaLocalPort, platformVersion);
		Thread.sleep(2000);
	}
	
	@Test
	public void AddTest() throws MalformedURLException, InterruptedException {
		//DriverFactory.launchIOSApp();
		Thread.sleep(2000);
		HomePage homePage = new HomePage();
		homePage.Add();
		System.out.println(homePage.getResult());
		Assert.assertEquals(homePage.getResult(), "10");
		DriverFactory.closeApp();
	}
	
	
	//@AfterMethod
	public void tearDown() {
		DriverFactory.closeApp();
	}
*/

}
