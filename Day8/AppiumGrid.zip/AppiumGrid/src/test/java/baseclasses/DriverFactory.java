package baseclasses;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.AutomationName;
import io.appium.java_client.remote.MobileCapabilityType;

public class DriverFactory {
	private static AppiumDriver<MobileElement> driver = null;
    static DesiredCapabilities cap;  
    
    public static void launchAndroidApp(String udid, int SystemPort, String platformVersion, int port) throws MalformedURLException {
    	cap = new DesiredCapabilities();
        cap.setCapability("platformName", "Android");
        cap.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.ANDROID_UIAUTOMATOR2);
        cap.setCapability("deviceName", udid);
        cap.setCapability(MobileCapabilityType.UDID, udid);
        cap.setCapability(AndroidMobileCapabilityType.SYSTEM_PORT, SystemPort);
        cap.setCapability("platformVersion", platformVersion);
    	cap.setCapability("appPackage", "com.android.calculator2");
		cap.setCapability("appActivity", ".Calculator");
		
        driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:"+port+"/wd/hub"), cap);
		//driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), cap);
        //System.out.println("Is App installed? " + driver.isAppInstalled("com.thomsonreuters.cs.samba"));
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        MobileDriver.setWebDriver(driver);
        Assert.assertNotNull(driver);
        System.out.println("Process" + Thread.currentThread().getId());
    }
    
    public static void launchIOSApp(String udid, int wdaLocalPort, String platformVersion) throws MalformedURLException {
    	cap = new DesiredCapabilities();
        cap.setCapability("platformName", "iOS");
        //cap.setCapability("deviceName", "iPhone X");
        cap.setCapability("platformVersion", platformVersion);
        cap.setCapability("automationName", "XCUITest");
        cap.setCapability("wdaLocalPort", wdaLocalPort);
        cap.setCapability(MobileCapabilityType.UDID, udid);
        cap.setCapability("bundleId", "com.SamadiPour.SimpleCalculator");          
        driver = new IOSDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), cap);
        //System.out.println("Is App installed? " + driver.isAppInstalled("com.thomsonreuters.samba"));
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        MobileDriver.setWebDriver(driver);
        Assert.assertNotNull(driver);
        System.out.println("Process" + Thread.currentThread().getId());
    }
    
    public static void closeApp() {
    	driver.quit();
    }
    
    
}


//to get the udid
//xcrun simctl -list | grep '(Booted)'
//adb devices
